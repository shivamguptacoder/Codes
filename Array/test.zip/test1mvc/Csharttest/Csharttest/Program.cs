﻿using Csharttest;
using System;

class Program
{
    public static void Main(string[] args)
    {
        List<Stall> stalls = new List<Stall>();
        Console.WriteLine("Enter the number of stalls");
        int noOfStalls = Convert.ToInt32(Console.ReadLine());
        for(int i = 0; i < noOfStalls; i++)
        {
            Console.WriteLine("Enter stall details - {0}", i);
            
            Console.WriteLine("Enter the name");

            string name = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter the owner name");

            string ownerName = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter the stall type");
            string stallType = Convert.ToString(Console.ReadLine());    
            stalls.Add(new Stall(name, ownerName, stallType));
        }
        Console.WriteLine(String.Format("{0,-15}{1,-15}{2,-20}", "Name", "Owner name", "Stall type"));
        foreach(Stall stall in stalls)
        {
        Console.WriteLine(String.Format("{0,-15}{1,-15}{2,-20}", stall.Name, stall.Owner, stall.StallType));

        }
    }
}