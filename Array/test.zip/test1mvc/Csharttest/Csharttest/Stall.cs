﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharttest
{
    internal class Stall
    {
        private string _name;
        private string _owner;
        private string _stallType;

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Owner
        {
            get
            {
                return _owner;
            }
            set
            {
                _owner = value;
            }
        }

        public string StallType
        {
            get
            {
                return _stallType;
            }
            set { _stallType = value; }
        }

        public Stall()
        {

        }
        public Stall(string name, string owner, string stallType)
        {
            this._name = name;
            this._owner = owner;
            this._stallType = stallType;
        }
    }
}
