﻿using Microsoft.AspNetCore.Mvc;
using mvc.Models;
using System;

namespace mvc.Controllers
{
    public class HallController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Index(string hallName,string ownerName,int costPerDay,string mobile,string address)
        {
            Hall hall = new Hall(1,hallName,ownerName,costPerDay,mobile,address);
            if(ModelState.IsValid)
            {
                return View("Details",hall);
            }
            return View();

        }
        public ActionResult Details(Hall hall)
        {
            ViewBag.HallName = hall.HallName;
            ViewBag.OwnerName = hall.OwnerName;
            ViewBag.CostPerDay = hall.CostPerDay;
            ViewBag.Mobile = hall.Mobile;
            ViewBag.Address = hall.Address;
            return View(hall);

        }
    }
}
