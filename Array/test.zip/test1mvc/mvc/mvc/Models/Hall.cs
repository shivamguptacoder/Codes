﻿using System.ComponentModel.DataAnnotations;

namespace mvc.Models
{
    public class Hall
    {
        [Key]
        int _id;
        string _hallName;
        string _ownerName;
        int _costPerDay;
        string _mobile;
        string _address;

        public Hall()
        {
        }

        public Hall(int id, string hallName, string ownerName, int costPerDay, string mobile, string address)
        {
            Id = id;
            HallName = hallName;
            OwnerName = ownerName;
            CostPerDay = costPerDay;
            Mobile = mobile;
            Address = address;
        }

        public int Id { get => _id; set => _id = value; }
        
        [Required(ErrorMessage = "Hall name is required")]
        public string HallName { get => _hallName; set => _hallName = value; }

        [Required(ErrorMessage = "Owner name is required")]
        public string OwnerName { get => _ownerName; set => _ownerName = value; }
        
        [Required(ErrorMessage = "Cost per day is required")]
        public int CostPerDay { get => _costPerDay; set => _costPerDay = value; }
        [Required(ErrorMessage = "Mobile number is required")]
        public string Mobile { get => _mobile; set => _mobile = value; }
        [Required(ErrorMessage = "Address is required")]
        public string Address { get => _address; set => _address = value; }

    }
}
