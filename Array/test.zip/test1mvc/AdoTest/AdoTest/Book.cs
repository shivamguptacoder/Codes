﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoTest
{
    internal class Book
    {

        private int _id;
        private string _title;
        private string _category;
        private string _author;
        private double _price;

        public Book(string _title, string _category, string _author, double _price)
        {
            this.Title = _title;
            this.Category = _category;
            this.Author = _author;
            this.Price = _price;
        }

        public Book(int _id, string _title, string _category, string _author, double _price)
        {
            this.Id = _id;
            this.Title = _title;
            this.Category = _category;
            this.Author = _author;
            this.Price = _price;
        }

        public int Id { get => _id; set => _id = value; }
        public string Title { get => _title; set => _title = value; }
        public string Category { get => _category; set => _category = value; }
        public string Author { get => _author; set => _author = value; }
        public double Price { get => _price; set => _price = value; }
    }
}
