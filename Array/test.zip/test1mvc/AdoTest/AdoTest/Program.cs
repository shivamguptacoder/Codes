﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int choice;
            BookBO bookBo = new BookBO();
            Console.WriteLine("Menu");
            Console.WriteLine("1.Add book");
            Console.WriteLine("2.Update price");
            Console.WriteLine("3.Delete book");
            Console.WriteLine("4.Exit");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Enter the title");
                    string title = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Enter the category");
                    string category = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Enter the author");
                    string author = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Enter the price");
                    double price = Convert.ToDouble(Console.ReadLine());
                    Book book = new Book(title,category,author,price);
                    bool result = bookBo.InsertBook(book);
                    
                    if (result)
                    {
                        Console.WriteLine("Book added successfully");
                        bookBo.DisplayBooks();
                    }
                    break;
                case 2:
                    Console.WriteLine("Enter the book id");
                    int bookId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the price");
                    double price2 = Convert.ToDouble(Console.ReadLine());
                    bool result2 = bookBo.UpdateBook(bookId,price2);
                    if (result2)
                    {
                        Console.WriteLine("Book updated successfully");
                        bookBo.DisplayBooks();
                    }
                    else
                    {
                        Console.WriteLine("Book not found");
                    }
                    break;
                case 3:
                    Console.WriteLine("Enter the book id");
                    int bookId3 = Convert.ToInt32(Console.ReadLine());
                    bool result3 = bookBo.DeleteBook(bookId3);
                    if (result3)
                    {
                        Console.WriteLine("Book deleted successfully");
                        bookBo.DisplayBooks();
                    }
                    else
                    {
                        Console.WriteLine("Book not deleted");

                    }
                    break;
                case 4:
                    break;

                default:
                    Console.WriteLine("Invalid input");
                    break;
            }
        }
    }
}
