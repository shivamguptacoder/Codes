﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoTest
{
    internal class BookDAO
    {
        SqlConnection conn = DBConnection.GetConnection();
        public bool InsertBook(Book book)
        {
            SqlCommand cmd = new SqlCommand("insert into book values(@Title,@Category,@Author,@Price)",conn);
            cmd.Parameters.Add("Title",SqlDbType.VarChar).Value = book.Title;
            cmd.Parameters.Add("Category",SqlDbType.VarChar).Value= book.Category;
            cmd.Parameters.Add("Author",SqlDbType.VarChar).Value= book.Author;
            cmd.Parameters.Add("Price", SqlDbType.Float).Value = book.Price;
            
            conn.Open();
            int a = cmd.ExecuteNonQuery();
            conn.Close();
            if (a > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdateBook(int bookId, double price)
        {
            SqlCommand cmd = new SqlCommand("update book set price = @Price where id = @Id",conn);
            cmd.Parameters.Add("Price", SqlDbType.Float).Value = price;
            cmd.Parameters.Add("Id", SqlDbType.Int).Value = bookId;
            conn.Open();
            int a = cmd.ExecuteNonQuery();
            conn.Close();
            if (a > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteBook(int bookId)
        {
            SqlCommand cmd = new SqlCommand("delete from book where id = @Id", conn);
            cmd.Parameters.Add("Id", SqlDbType.Int).Value = bookId;
            conn.Open();
            int a = cmd.ExecuteNonQuery();
            conn.Close();
            if (a > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<Book> GetAllBook()
        {
            List<Book> bookList = new List<Book>();
            SqlCommand cmd = new SqlCommand("select * from book", conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                bookList.Add(new Book(
                    Convert.ToInt32(reader["id"]),
                    Convert.ToString(reader["title"]),
                    Convert.ToString(reader["category"]),
                    Convert.ToString(reader["author"]),
                    Convert.ToDouble(reader["price"])

                    ));
            }
            reader.Close();
            conn.Close();
            return bookList;
        }
    }
}
