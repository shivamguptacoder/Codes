﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoTest
{
    internal class BookBO
    {
        public bool InsertBook(Book book)
        {
            return new BookDAO().InsertBook(book);
        }

        public bool UpdateBook(int bookId, double price)
        {
            return new BookDAO().UpdateBook(bookId, price);
        }

        public bool DeleteBook(int bookId)
        {
            return new BookDAO().DeleteBook(bookId);
        }
        public void DisplayBooks()
        {
            List<Book> bookList = new BookDAO().GetAllBook();
            if (bookList.Count > 0)
            {
                Console.WriteLine(String.Format("{0,-5}{1,-15}{2,-10}{3,-10}{4}", "Id", "Title", "Category", "Author", "Price"));
                foreach (Book b in bookList)
                {
                    Console.WriteLine(String.Format("{0,-5}{1,-15}{2,-10}{3,-10}{4}", b.Id, b.Title, b.Category, b.Author, b.Price));

                }
            }
            else
            {
                Console.WriteLine("Book list is empty");
            }
        }
    }
}
